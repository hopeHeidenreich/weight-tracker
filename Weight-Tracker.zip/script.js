var peopleContact = [];
var file;

var registry = {};


window.onload = function () {
    $('#file').change(function (e) {
        var pic = '';
        

        file = document.getElementById('file').files[0];
        var imageType = /image.*/;

        if (file.type.match(imageType)) {
            var reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = function (e) {
                var image = document.getElementById('img');
                image.src = reader.result;

                registry.pic = reader.result;
            }
        }
    }) 
    displayData()
}

function submitRegister() { 
    registry.fname = document.getElementById('fname').value;
    registry.lname = document.getElementById('lname').value;
    registry.numb = document.getElementById('numb').value;
    registry.weight = document.getElementById('weight').value;
    registry.date = document.getElementById('date').value;

    let people = JSON.parse(localStorage.getItem('peopleRegistered'));
    if (people == null) people = [];

    if (registry.fname != '' || registry.lname != '' || registry.numb != '' || registry.weight != '' || registry.date != '') {
        people.push(registry);
    } else {
        alert('Please fill out all fields..');
        return
    };

    localStorage.setItem('peopleRegistered', JSON.stringify(people))


    document.getElementById('fname').value = '';
    document.getElementById('lname').value = '';
    document.getElementById('numb').value = '';
    document.getElementById('weight').value = '';
    document.getElementById('date').value = '';

}

function displayData() {
    var people = JSON.parse(localStorage.getItem('peopleRegistered'))
    var txt = '';

    for (var i = 0; i < people.length; i++) {
        txt += `<tr>
                    <td>${people[i].fname}</td>
                    <td>${people[i].lname}</td>
                    <td>${people[i].numb}</td>
                    <td><img src="${people[i].pic}" style="width:64px; height:64px; border:ridge; border-radius:5px" /></td>
                    <td>
                        <b>Details...</b> <br>
                        ${people[i].date}: ${people[i].weight} lbs.
                    </td>
                    <td><button class="btn btn-link" onclick="deleteItem('${i}')"> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash-fill" viewBox="0 0 16 16">
                    <path d="M2.5 1a1 1 0 0 0-1 1v1a1 1 0 0 0 1 1H3v9a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V4h.5a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H10a1 1 0 0 0-1-1H7a1 1 0 0 0-1 1H2.5zm3 4a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 .5-.5zM8 5a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-1 0v-7A.5.5 0 0 1 8 5zm3 .5v7a.5.5 0 0 1-1 0v-7a.5.5 0 0 1 1 0z"/>
                  </svg></button></td>
                </tr>`
    };

    document.getElementById('data').innerHTML = txt;
}

function submitContact() {
    var contactInfo = {
        name: document.getElementById('name2').value,
        email: document.getElementById('email').value,
        sub: document.getElementById('subject').value,
        msg: document.getElementById('msg').value,
    }

    if (contactInfo.name != '' || contactInfo.email != '' || contactInfo.sub != '' || contactInfo.msg != '') {
        peopleContact.push(contactInfo)
    } else {
        alert('Please fill out all fields..');
        return;
    }

    localStorage.setItem('contactInfo', JSON.stringify(peopleContact));
    localStorage.setItem(contactInfo.name, JSON.stringify(peopleContact));

    document.getElementById('name2').value = '';
    document.getElementById('email').value = '';
    document.getElementById('subject').value = '';
    document.getElementById('msg').value = '';
}

function deleteItem(i) {
    var people = JSON.parse(localStorage.getItem('peopleRegistered'))

    people.splice(i, 1);

    localStorage.setItem('peopleRegistered', JSON.stringify(people));
    displayData();
}
